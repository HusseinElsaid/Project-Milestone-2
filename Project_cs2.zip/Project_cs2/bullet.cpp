#include "bullet.h"

bullet::bullet()
{

}
