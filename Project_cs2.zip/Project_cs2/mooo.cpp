#include "mooo.h"

mooo::mooo()
{

}
