#ifndef BULLET_H
#define BULLET_H


class bullet
{
public:
    bullet();
};

#endif // BULLET_H
