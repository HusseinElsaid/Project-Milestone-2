#ifndef PELLET_H
#define PELLET_H


class pellet
{
public:
    pellet();
};

#endif // PELLET_H
