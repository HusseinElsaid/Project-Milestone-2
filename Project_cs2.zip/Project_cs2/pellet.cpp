#include "pellet.h"

pellet::pellet()
{

}
