#ifndef COORDINATES_H
#define COORDINATES_H


class coordinates
{
    int row, col;
public:
    coordinates();
    coordinates(int row, int col);
    int getRow();
    int getColumn();
};

#endif // COORDINATES_H
