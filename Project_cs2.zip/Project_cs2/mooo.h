#ifndef MOOO_H
#define MOOO_H


class mooo
{
public:
    mooo();
};

#endif // MOOO_H
